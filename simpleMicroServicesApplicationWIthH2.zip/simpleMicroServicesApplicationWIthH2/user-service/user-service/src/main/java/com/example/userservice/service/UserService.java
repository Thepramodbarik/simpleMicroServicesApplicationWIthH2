package com.example.userservice.service;


import java.util.logging.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.example.userservice.VO.Department;
import com.example.userservice.VO.ResponseTemplateVO;
import com.example.userservice.entity.User;
import com.example.userservice.repository.UserRepository;
import lombok.extern.slf4j.Slf4j;



@Service
public class UserService {

	Logger log = Logger.getLogger(UserService.class.getName());

	@Autowired
	private UserRepository userRepository;
	@Autowired
	private RestTemplate restTemplate;


	public User saveUser(User user) {

		return userRepository.save(user);
	}

	public ResponseTemplateVO getUserWithDepartment(Long userId) {

		ResponseTemplateVO vo = new ResponseTemplateVO();
		User user = userRepository.findByUserId(userId);

		log.info("findUserDetailsById-Id=" + userId);

		Department department = restTemplate
				.getForObject("http://DEPARTMENT-SERVICE/departments/" + user.getDepartmentId(), Department.class);
		vo.setUser(user);
		vo.setDepartment(department);

		log.info("findUserDetailsById-Id=" + userId + "|user=+" + user + "|department=" + department);

		return vo;
	}

}
